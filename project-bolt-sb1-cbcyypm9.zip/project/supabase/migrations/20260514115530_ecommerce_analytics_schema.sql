/*
  # E-Commerce Customer Analytics & Prediction Schema

  ## Overview
  Full schema for an AI-powered e-commerce analytics dashboard with customer segmentation,
  churn prediction, revenue forecasting, and product recommendations.

  ## Tables
  1. `products` - Product catalog with category, pricing, and stock info
  2. `customers` - Customer profiles with ML-derived segments, churn risk, and LTV scores
  3. `orders` - Order transactions linked to customers
  4. `order_items` - Line items per order linked to products
  5. `revenue_metrics` - Daily aggregated revenue snapshots
  6. `predictions` - AI model output: churn probabilities, LTV forecasts, recommendations

  ## Security
  - RLS enabled on all tables
  - Authenticated users can read all analytics data
  - Only service role can write (data managed server-side)
*/

-- ============================================================
-- PRODUCTS
-- ============================================================
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  price numeric(10,2) NOT NULL,
  cost numeric(10,2) NOT NULL,
  stock integer NOT NULL DEFAULT 0,
  rating numeric(3,2) NOT NULL DEFAULT 4.0,
  reviews_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read products"
  ON products FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);

-- ============================================================
-- CUSTOMERS
-- ============================================================
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  segment text NOT NULL DEFAULT 'regular',
  churn_risk numeric(5,4) NOT NULL DEFAULT 0,
  ltv numeric(10,2) NOT NULL DEFAULT 0,
  predicted_ltv numeric(10,2) NOT NULL DEFAULT 0,
  total_orders integer NOT NULL DEFAULT 0,
  total_spent numeric(10,2) NOT NULL DEFAULT 0,
  avg_order_value numeric(10,2) NOT NULL DEFAULT 0,
  days_since_last_order integer NOT NULL DEFAULT 0,
  acquisition_channel text NOT NULL DEFAULT 'organic',
  country text NOT NULL DEFAULT 'US',
  last_order_date timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE customers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read customers"
  ON customers FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);

-- ============================================================
-- ORDERS
-- ============================================================
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  total numeric(10,2) NOT NULL,
  status text NOT NULL DEFAULT 'completed',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);

-- ============================================================
-- ORDER ITEMS
-- ============================================================
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id),
  quantity integer NOT NULL DEFAULT 1,
  price numeric(10,2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);

-- ============================================================
-- REVENUE METRICS (daily aggregates)
-- ============================================================
CREATE TABLE IF NOT EXISTS revenue_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL UNIQUE,
  revenue numeric(10,2) NOT NULL DEFAULT 0,
  orders integer NOT NULL DEFAULT 0,
  new_customers integer NOT NULL DEFAULT 0,
  avg_order_value numeric(10,2) NOT NULL DEFAULT 0,
  forecast_revenue numeric(10,2),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE revenue_metrics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read revenue metrics"
  ON revenue_metrics FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);

-- ============================================================
-- PREDICTIONS (AI model outputs)
-- ============================================================
CREATE TABLE IF NOT EXISTS predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  prediction_type text NOT NULL,
  value numeric(10,4) NOT NULL,
  confidence numeric(5,4) NOT NULL,
  features jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE predictions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read predictions"
  ON predictions FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product_id ON order_items(product_id);
CREATE INDEX IF NOT EXISTS idx_customers_segment ON customers(segment);
CREATE INDEX IF NOT EXISTS idx_customers_churn_risk ON customers(churn_risk DESC);
CREATE INDEX IF NOT EXISTS idx_revenue_metrics_date ON revenue_metrics(date);
CREATE INDEX IF NOT EXISTS idx_predictions_customer_id ON predictions(customer_id);

-- ============================================================
-- SEED: PRODUCTS
-- ============================================================
INSERT INTO products (name, category, price, cost, stock, rating, reviews_count) VALUES
  ('Pro Wireless Headphones', 'Electronics', 299.99, 89.00, 450, 4.7, 2341),
  ('Ergonomic Office Chair', 'Furniture', 599.99, 180.00, 120, 4.5, 876),
  ('Smart Fitness Watch', 'Wearables', 249.99, 75.00, 680, 4.6, 3102),
  ('Mechanical Keyboard', 'Electronics', 149.99, 45.00, 320, 4.8, 1845),
  ('4K Webcam', 'Electronics', 199.99, 60.00, 290, 4.4, 921),
  ('Standing Desk Mat', 'Furniture', 79.99, 22.00, 740, 4.3, 634),
  ('Laptop Stand', 'Accessories', 59.99, 15.00, 890, 4.6, 2103),
  ('USB-C Hub 7-in-1', 'Accessories', 89.99, 25.00, 1200, 4.5, 1567),
  ('Noise Cancelling Earbuds', 'Electronics', 179.99, 52.00, 560, 4.7, 4210),
  ('Monitor Light Bar', 'Accessories', 49.99, 14.00, 430, 4.4, 789),
  ('Portable SSD 1TB', 'Storage', 119.99, 38.00, 380, 4.9, 2890),
  ('Wireless Charging Pad', 'Accessories', 39.99, 11.00, 950, 4.2, 1234),
  ('Smart Speaker', 'Electronics', 129.99, 40.00, 340, 4.3, 1678),
  ('Gaming Mouse', 'Peripherals', 79.99, 22.00, 620, 4.7, 3421),
  ('Cable Management Kit', 'Accessories', 29.99, 8.00, 1500, 4.5, 567)
ON CONFLICT DO NOTHING;

-- ============================================================
-- SEED: CUSTOMERS (200 records via generate_series)
-- ============================================================
INSERT INTO customers (name, email, segment, churn_risk, ltv, predicted_ltv, total_orders, total_spent, avg_order_value, days_since_last_order, acquisition_channel, country, last_order_date, created_at)
SELECT
  'Customer ' || i AS name,
  'customer' || i || '@ecomm.io' AS email,
  CASE ((i * 7 + 3) % 5)
    WHEN 0 THEN 'vip'
    WHEN 1 THEN 'regular'
    WHEN 2 THEN 'new'
    WHEN 3 THEN 'at_risk'
    ELSE 'dormant'
  END AS segment,
  ROUND((
    CASE ((i * 7 + 3) % 5)
      WHEN 3 THEN 0.55 + (i % 30)::numeric / 100
      WHEN 4 THEN 0.65 + (i % 20)::numeric / 100
      ELSE (i % 35)::numeric / 100
    END
  )::numeric, 4) AS churn_risk,
  ROUND((
    CASE ((i * 7 + 3) % 5)
      WHEN 0 THEN 3000 + (i * 17 % 4000)
      WHEN 1 THEN 500 + (i * 13 % 2000)
      WHEN 2 THEN 50 + (i * 11 % 500)
      WHEN 3 THEN 200 + (i * 9 % 1500)
      ELSE 100 + (i * 7 % 800)
    END
  )::numeric, 2) AS ltv,
  ROUND((
    CASE ((i * 7 + 3) % 5)
      WHEN 0 THEN 4500 + (i * 19 % 6000)
      WHEN 1 THEN 800 + (i * 15 % 3000)
      WHEN 2 THEN 150 + (i * 13 % 800)
      WHEN 3 THEN 300 + (i * 11 % 1000)
      ELSE 80 + (i * 9 % 400)
    END
  )::numeric, 2) AS predicted_ltv,
  CASE ((i * 7 + 3) % 5)
    WHEN 0 THEN 15 + (i % 30)
    WHEN 1 THEN 5 + (i % 20)
    WHEN 2 THEN 1 + (i % 3)
    WHEN 3 THEN 3 + (i % 10)
    ELSE 1 + (i % 4)
  END AS total_orders,
  ROUND((
    CASE ((i * 7 + 3) % 5)
      WHEN 0 THEN 2800 + (i * 17 % 3500)
      WHEN 1 THEN 400 + (i * 13 % 1800)
      WHEN 2 THEN 40 + (i * 11 % 450)
      WHEN 3 THEN 180 + (i * 9 % 1200)
      ELSE 90 + (i * 7 % 700)
    END
  )::numeric, 2) AS total_spent,
  ROUND((
    100 + (i * 23 % 300)
  )::numeric, 2) AS avg_order_value,
  CASE ((i * 7 + 3) % 5)
    WHEN 0 THEN (i % 15)
    WHEN 1 THEN (i % 30)
    WHEN 2 THEN (i % 7)
    WHEN 3 THEN 60 + (i % 90)
    ELSE 120 + (i % 180)
  END AS days_since_last_order,
  CASE (i % 4)
    WHEN 0 THEN 'organic'
    WHEN 1 THEN 'paid_search'
    WHEN 2 THEN 'email'
    ELSE 'social'
  END AS acquisition_channel,
  CASE (i % 6)
    WHEN 0 THEN 'US'
    WHEN 1 THEN 'US'
    WHEN 2 THEN 'UK'
    WHEN 3 THEN 'CA'
    WHEN 4 THEN 'AU'
    ELSE 'DE'
  END AS country,
  now() - ((i % 90)::text || ' days')::interval AS last_order_date,
  now() - ((i * 3 % 730)::text || ' days')::interval AS created_at
FROM generate_series(1, 200) i
ON CONFLICT (email) DO NOTHING;

-- ============================================================
-- SEED: REVENUE METRICS (last 90 days + 30 days forecast)
-- ============================================================
INSERT INTO revenue_metrics (date, revenue, orders, new_customers, avg_order_value, forecast_revenue)
SELECT
  (current_date - (90 - i)::integer) AS date,
  ROUND((
    18000
    + 5000 * sin(i::float / 7)
    + 3000 * sin(i::float / 30)
    + (i * 47 % 2000)
    + i * 80
  )::numeric, 2) AS revenue,
  (120 + (i % 40) + (i * 3 % 20))::integer AS orders,
  (8 + (i % 5))::integer AS new_customers,
  ROUND((
    140 + (i * 23 % 60)
  )::numeric, 2) AS avg_order_value,
  NULL AS forecast_revenue
FROM generate_series(0, 90) i
ON CONFLICT (date) DO NOTHING;

-- Add 30-day forecast
INSERT INTO revenue_metrics (date, revenue, orders, new_customers, avg_order_value, forecast_revenue)
SELECT
  (current_date + i::integer) AS date,
  0 AS revenue,
  0 AS orders,
  0 AS new_customers,
  0 AS avg_order_value,
  ROUND((
    26000
    + 5500 * sin(i::float / 7)
    + 3500 * sin(i::float / 30)
    + i * 95
  )::numeric, 2) AS forecast_revenue
FROM generate_series(1, 30) i
ON CONFLICT (date) DO NOTHING;
