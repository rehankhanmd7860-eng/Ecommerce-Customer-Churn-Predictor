import { useState } from 'react';
import { AuthProvider, useAuth } from './lib/AuthContext';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import Overview from './pages/Overview';
import CustomerAnalytics from './pages/CustomerAnalytics';
import ChurnPrediction from './pages/ChurnPrediction';
import RevenueForecast from './pages/RevenueForecast';
import ProductInsights from './pages/ProductInsights';
import type { Page } from './lib/types';

function Dashboard() {
  const [page, setPage] = useState<Page>('overview');
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="flex items-center gap-3 text-slate-400">
          <div className="w-5 h-5 border-2 border-slate-600 border-t-blue-500 rounded-full animate-spin" />
          <span className="text-sm">Loading analytics platform...</span>
        </div>
      </div>
    );
  }

  if (!user) return <LoginPage />;

  const pageContent: Record<Page, JSX.Element> = {
    overview: <Overview />,
    customers: <CustomerAnalytics />,
    churn: <ChurnPrediction />,
    forecast: <RevenueForecast />,
    products: <ProductInsights />,
  };

  return (
    <Layout currentPage={page} onNavigate={setPage}>
      {pageContent[page]}
    </Layout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Dashboard />
    </AuthProvider>
  );
}
