export type CustomerSegment = 'vip' | 'regular' | 'new' | 'at_risk' | 'dormant';
export type AcquisitionChannel = 'organic' | 'paid_search' | 'email' | 'social';

export interface Customer {
  id: string;
  name: string;
  email: string;
  segment: CustomerSegment;
  churn_risk: number;
  ltv: number;
  predicted_ltv: number;
  total_orders: number;
  total_spent: number;
  avg_order_value: number;
  days_since_last_order: number;
  acquisition_channel: string;
  country: string;
  last_order_date: string | null;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  cost: number;
  stock: number;
  rating: number;
  reviews_count: number;
  created_at: string;
}

export interface RevenueMetric {
  id: string;
  date: string;
  revenue: number;
  orders: number;
  new_customers: number;
  avg_order_value: number;
  forecast_revenue: number | null;
}

export interface KPIData {
  label: string;
  value: string;
  change: number;
  trend: 'up' | 'down' | 'neutral';
  icon: string;
}

export interface ChartDataPoint {
  label: string;
  value: number;
  secondary?: number;
  color?: string;
}

export interface SegmentCount {
  segment: CustomerSegment;
  count: number;
  percentage: number;
  avg_ltv: number;
  avg_churn_risk: number;
}

export interface ModelFeature {
  name: string;
  importance: number;
}

export type Page = 'overview' | 'customers' | 'churn' | 'forecast' | 'products';
