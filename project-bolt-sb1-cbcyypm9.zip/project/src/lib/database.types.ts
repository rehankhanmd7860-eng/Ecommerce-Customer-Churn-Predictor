export type Json = string | number | boolean | null | { [key: string]: Json } | Json[];

export interface Database {
  public: {
    Tables: {
      customers: {
        Row: {
          id: string;
          name: string;
          email: string;
          segment: string;
          churn_risk: number;
          ltv: number;
          predicted_ltv: number;
          total_orders: number;
          total_spent: number;
          avg_order_value: number;
          days_since_last_order: number;
          acquisition_channel: string;
          country: string;
          last_order_date: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['customers']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['customers']['Insert']>;
      };
      products: {
        Row: {
          id: string;
          name: string;
          category: string;
          price: number;
          cost: number;
          stock: number;
          rating: number;
          reviews_count: number;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['products']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['products']['Insert']>;
      };
      orders: {
        Row: {
          id: string;
          customer_id: string;
          total: number;
          status: string;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['orders']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['orders']['Insert']>;
      };
      order_items: {
        Row: {
          id: string;
          order_id: string;
          product_id: string;
          quantity: number;
          price: number;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['order_items']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['order_items']['Insert']>;
      };
      revenue_metrics: {
        Row: {
          id: string;
          date: string;
          revenue: number;
          orders: number;
          new_customers: number;
          avg_order_value: number;
          forecast_revenue: number | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['revenue_metrics']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['revenue_metrics']['Insert']>;
      };
      predictions: {
        Row: {
          id: string;
          customer_id: string;
          prediction_type: string;
          value: number;
          confidence: number;
          features: Json;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['predictions']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['predictions']['Insert']>;
      };
    };
  };
}
