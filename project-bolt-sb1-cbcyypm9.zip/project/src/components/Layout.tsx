import { ReactNode } from 'react';
import {
  LayoutDashboard, Users, AlertTriangle, TrendingUp, ShoppingBag,
  LogOut, BrainCircuit, ChevronRight, Bell, Settings
} from 'lucide-react';
import type { Page } from '../lib/types';
import { useAuth } from '../lib/AuthContext';

interface NavItem {
  id: Page;
  label: string;
  icon: ReactNode;
  badge?: string;
}

const navItems: NavItem[] = [
  { id: 'overview', label: 'Overview', icon: <LayoutDashboard size={18} /> },
  { id: 'customers', label: 'Customer Analytics', icon: <Users size={18} /> },
  { id: 'churn', label: 'Churn Prediction', icon: <AlertTriangle size={18} />, badge: 'AI' },
  { id: 'forecast', label: 'Revenue Forecast', icon: <TrendingUp size={18} />, badge: 'AI' },
  { id: 'products', label: 'Product Insights', icon: <ShoppingBag size={18} /> },
];

interface LayoutProps {
  children: ReactNode;
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

export default function Layout({ children, currentPage, onNavigate }: LayoutProps) {
  const { user, signOut } = useAuth();

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 flex-shrink-0 border-r border-slate-800 flex flex-col bg-slate-900">
        {/* Brand */}
        <div className="px-5 py-5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <BrainCircuit size={16} className="text-white" />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-100 leading-tight">E-Commerce AI</div>
              <div className="text-xs text-slate-500 leading-tight">Analytics Platform</div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 overflow-y-auto">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-2 mb-3">Analytics</div>
          <ul className="space-y-0.5">
            {navItems.map(item => {
              const isActive = currentPage === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => onNavigate(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                      isActive
                        ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    }`}
                  >
                    <span className={isActive ? 'text-blue-400' : 'text-slate-500'}>{item.icon}</span>
                    <span className="flex-1 text-left font-medium">{item.label}</span>
                    {item.badge && (
                      <span className="text-xs bg-cyan-500/20 text-cyan-400 px-1.5 py-0.5 rounded font-semibold">
                        {item.badge}
                      </span>
                    )}
                    {isActive && <ChevronRight size={14} className="text-blue-400" />}
                  </button>
                </li>
              );
            })}
          </ul>

          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-2 mb-3 mt-6">System</div>
          <ul className="space-y-0.5">
            <li>
              <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition-all">
                <Settings size={18} className="text-slate-500" />
                <span className="font-medium">Settings</span>
              </button>
            </li>
          </ul>
        </nav>

        {/* User footer */}
        <div className="px-3 py-3 border-t border-slate-800">
          <div className="flex items-center gap-3 px-2 py-2 rounded-lg">
            <div className="w-7 h-7 rounded-full bg-blue-600/30 border border-blue-600/50 flex items-center justify-center text-xs font-bold text-blue-400">
              {user?.email?.[0]?.toUpperCase() ?? 'A'}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold text-slate-300 truncate">{user?.email ?? 'Admin'}</div>
              <div className="text-xs text-slate-500">Administrator</div>
            </div>
            <button onClick={signOut} className="text-slate-500 hover:text-red-400 transition-colors" title="Sign out">
              <LogOut size={14} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top header */}
        <header className="h-14 border-b border-slate-800 bg-slate-900 flex items-center px-6 gap-4 flex-shrink-0">
          <div className="flex-1">
            <h1 className="text-sm font-semibold text-slate-200">
              {navItems.find(n => n.id === currentPage)?.label ?? 'Dashboard'}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-400/10 px-2.5 py-1 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              ML Models Active
            </div>
            <button className="text-slate-400 hover:text-slate-200 transition-colors relative">
              <Bell size={18} />
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-red-500" />
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6 bg-slate-950">
          {children}
        </main>
      </div>
    </div>
  );
}
