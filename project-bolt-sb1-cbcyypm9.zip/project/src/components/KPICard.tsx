import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { ReactNode } from 'react';

interface KPICardProps {
  label: string;
  value: string;
  change?: number;
  subtitle?: string;
  icon: ReactNode;
  accent?: string;
  loading?: boolean;
}

export default function KPICard({ label, value, change, subtitle, icon, accent = '#3b82f6', loading }: KPICardProps) {
  const isPositive = (change ?? 0) >= 0;
  const isNeutral = change === undefined;

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-xl p-5 flex flex-col gap-3 hover:border-slate-600 transition-colors">
      <div className="flex items-start justify-between">
        <div className="p-2.5 rounded-lg" style={{ backgroundColor: `${accent}20` }}>
          <div style={{ color: accent }}>{icon}</div>
        </div>
        {!isNeutral && (
          <div className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full ${
            isPositive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
          }`}>
            {isPositive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
            {Math.abs(change!).toFixed(1)}%
          </div>
        )}
      </div>
      {loading ? (
        <div className="space-y-2">
          <div className="h-7 w-24 bg-slate-700 rounded animate-pulse" />
          <div className="h-4 w-32 bg-slate-700 rounded animate-pulse" />
        </div>
      ) : (
        <div>
          <div className="text-2xl font-bold text-slate-100 tabular-nums">{value}</div>
          <div className="text-sm text-slate-400 mt-0.5">{label}</div>
          {subtitle && <div className="text-xs text-slate-500 mt-1">{subtitle}</div>}
        </div>
      )}
    </div>
  );
}
