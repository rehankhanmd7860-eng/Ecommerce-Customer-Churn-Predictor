import { useMemo } from 'react';

interface DataPoint {
  label: string;
  value: number;
  forecast?: number;
}

interface LineChartProps {
  data: DataPoint[];
  height?: number;
  color?: string;
  forecastColor?: string;
  showForecast?: boolean;
  showGrid?: boolean;
  formatValue?: (v: number) => string;
}

export default function LineChart({
  data,
  height = 200,
  color = '#3b82f6',
  forecastColor = '#06b6d4',
  showForecast = false,
  showGrid = true,
  formatValue = (v) => v.toLocaleString(),
}: LineChartProps) {
  const width = 600;
  const padL = 0;
  const padR = 0;
  const padT = 10;
  const padB = 24;

  const { actual, forecast, minV, maxV } = useMemo(() => {
    const allVals = data.flatMap(d => [d.value, ...(d.forecast !== undefined ? [d.forecast] : [])]).filter(v => v > 0);
    const minV = Math.min(...allVals) * 0.9;
    const maxV = Math.max(...allVals) * 1.05;
    const scaleX = (i: number) => padL + (i / (data.length - 1)) * (width - padL - padR);
    const scaleY = (v: number) => padT + (1 - (v - minV) / (maxV - minV)) * (height - padT - padB);

    const actual = data
      .filter(d => d.value > 0)
      .map((d, i) => ({ x: scaleX(i), y: scaleY(d.value), label: d.label, value: d.value }));

    const forecast = data
      .filter(d => (d.forecast ?? 0) > 0)
      .map((d, i) => ({ x: scaleX(data.indexOf(d)), y: scaleY(d.forecast!), label: d.label, value: d.forecast! }));

    return { actual, forecast, minV, maxV };
  }, [data, height]);

  const toPath = (pts: { x: number; y: number }[]) =>
    pts.length < 2 ? '' : `M ${pts.map(p => `${p.x},${p.y}`).join(' L ')}`;

  const toArea = (pts: { x: number; y: number }[]) => {
    if (pts.length < 2) return '';
    const base = height - padB;
    return `M ${pts[0].x},${base} L ${pts.map(p => `${p.x},${p.y}`).join(' L ')} L ${pts[pts.length - 1].x},${base} Z`;
  };

  const gridLines = 4;
  const gradId = `grad-${color.replace('#', '')}`;
  const gradForecastId = `grad-fc-${forecastColor.replace('#', '')}`;

  return (
    <div className="w-full overflow-hidden">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ height }}>
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.3" />
            <stop offset="100%" stopColor={color} stopOpacity="0.02" />
          </linearGradient>
          <linearGradient id={gradForecastId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={forecastColor} stopOpacity="0.25" />
            <stop offset="100%" stopColor={forecastColor} stopOpacity="0.02" />
          </linearGradient>
        </defs>

        {showGrid && Array.from({ length: gridLines }).map((_, i) => {
          const y = 10 + (i / (gridLines - 1)) * (height - padT - padB);
          const val = maxV - (i / (gridLines - 1)) * (maxV - minV);
          return (
            <g key={i}>
              <line x1={padL} y1={y} x2={width - padR} y2={y} stroke="#334155" strokeWidth="1" strokeDasharray="4,4" />
              <text x={padL + 2} y={y - 4} fill="#64748b" fontSize="9" fontFamily="monospace">
                {formatValue(val)}
              </text>
            </g>
          );
        })}

        {/* Area fills */}
        {actual.length > 1 && <path d={toArea(actual)} fill={`url(#${gradId})`} />}
        {showForecast && forecast.length > 1 && <path d={toArea(forecast)} fill={`url(#${gradForecastId})`} />}

        {/* Lines */}
        {actual.length > 1 && (
          <path d={toPath(actual)} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        )}
        {showForecast && forecast.length > 1 && (
          <path d={toPath(forecast)} fill="none" stroke={forecastColor} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="6,3" />
        )}

        {/* Dots on last actual point */}
        {actual.length > 0 && (
          <circle cx={actual[actual.length - 1].x} cy={actual[actual.length - 1].y} r="3.5" fill={color} />
        )}

        {/* X axis labels */}
        {data.filter((_, i) => i % Math.ceil(data.length / 8) === 0).map((d, _, arr) => {
          const idx = data.indexOf(d);
          const x = padL + (idx / (data.length - 1)) * (width - padL - padR);
          return (
            <text key={idx} x={x} y={height - 4} textAnchor="middle" fill="#64748b" fontSize="9" fontFamily="monospace">
              {d.label}
            </text>
          );
        })}
      </svg>
    </div>
  );
}
