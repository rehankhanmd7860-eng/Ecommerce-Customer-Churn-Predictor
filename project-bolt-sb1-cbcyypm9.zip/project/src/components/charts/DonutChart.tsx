interface DonutSegment {
  label: string;
  value: number;
  color: string;
}

interface DonutChartProps {
  data: DonutSegment[];
  size?: number;
  thickness?: number;
  centerLabel?: string;
  centerValue?: string;
}

function polarToXY(cx: number, cy: number, r: number, angle: number) {
  const rad = (angle - 90) * (Math.PI / 180);
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function arcPath(cx: number, cy: number, r: number, startAngle: number, endAngle: number) {
  const start = polarToXY(cx, cy, r, startAngle);
  const end = polarToXY(cx, cy, r, endAngle);
  const largeArc = endAngle - startAngle > 180 ? 1 : 0;
  return `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArc} 1 ${end.x} ${end.y}`;
}

export default function DonutChart({
  data,
  size = 180,
  thickness = 36,
  centerLabel = 'Total',
  centerValue,
}: DonutChartProps) {
  const cx = size / 2;
  const cy = size / 2;
  const r = (size / 2) - thickness / 2 - 4;
  const total = data.reduce((s, d) => s + d.value, 0);
  const displayValue = centerValue ?? total.toLocaleString();

  let currentAngle = 0;
  const segments = data.map(d => {
    const sweep = (d.value / total) * 360;
    const start = currentAngle;
    currentAngle += sweep;
    return { ...d, startAngle: start, endAngle: currentAngle - 0.5, sweep };
  });

  return (
    <div className="flex items-center gap-6">
      <div className="relative flex-shrink-0">
        <svg width={size} height={size}>
          {segments.map((seg, i) => (
            <path
              key={i}
              d={arcPath(cx, cy, r, seg.startAngle, seg.endAngle)}
              fill="none"
              stroke={seg.color}
              strokeWidth={thickness}
              strokeLinecap="round"
            />
          ))}
          <text x={cx} y={cy - 8} textAnchor="middle" fill="#f1f5f9" fontSize="18" fontWeight="700" fontFamily="sans-serif">
            {displayValue}
          </text>
          <text x={cx} y={cy + 12} textAnchor="middle" fill="#64748b" fontSize="11" fontFamily="sans-serif">
            {centerLabel}
          </text>
        </svg>
      </div>
      <div className="flex flex-col gap-2 min-w-0">
        {segments.map((seg, i) => (
          <div key={i} className="flex items-center gap-2 text-sm">
            <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: seg.color }} />
            <span className="text-slate-400 truncate text-xs">{seg.label}</span>
            <span className="text-slate-200 font-semibold ml-auto text-xs tabular-nums">
              {((seg.value / total) * 100).toFixed(1)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
