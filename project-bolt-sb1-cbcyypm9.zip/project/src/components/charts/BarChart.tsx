interface BarDataPoint {
  label: string;
  value: number;
  color?: string;
}

interface BarChartProps {
  data: BarDataPoint[];
  height?: number;
  color?: string;
  horizontal?: boolean;
  formatValue?: (v: number) => string;
}

export default function BarChart({
  data,
  height = 200,
  color = '#3b82f6',
  horizontal = false,
  formatValue = (v) => v.toLocaleString(),
}: BarChartProps) {
  const maxVal = Math.max(...data.map(d => d.value));
  const padB = horizontal ? 0 : 28;
  const padL = horizontal ? 80 : 0;
  const padT = 8;
  const padR = 0;
  const svgW = 600;
  const barGap = 0.2;

  if (horizontal) {
    const rowH = Math.min(32, (height - padT) / data.length);
    const actualH = data.length * rowH + padT;
    return (
      <div className="w-full overflow-hidden">
        <svg viewBox={`0 0 ${svgW} ${actualH}`} className="w-full" style={{ height: actualH }}>
          {data.map((d, i) => {
            const barW = ((d.value / maxVal) * (svgW - padL - padR - 40));
            const y = padT + i * rowH;
            const barColor = d.color || color;
            return (
              <g key={i}>
                <text x={padL - 4} y={y + rowH * 0.65} textAnchor="end" fill="#94a3b8" fontSize="10" fontFamily="sans-serif">
                  {d.label}
                </text>
                <rect x={padL} y={y + rowH * 0.1} width={Math.max(barW, 2)} height={rowH * 0.8} rx="3"
                  fill={barColor} opacity="0.85" />
                <text x={padL + barW + 6} y={y + rowH * 0.65} fill="#cbd5e1" fontSize="10" fontFamily="monospace">
                  {formatValue(d.value)}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    );
  }

  const barW = (svgW - padL - padR) / data.length;
  return (
    <div className="w-full overflow-hidden">
      <svg viewBox={`0 0 ${svgW} ${height}`} className="w-full" style={{ height }}>
        {data.map((d, i) => {
          const barH = ((d.value / maxVal) * (height - padT - padB));
          const x = padL + i * barW + barW * barGap;
          const w = barW * (1 - barGap * 2);
          const y = padT + (height - padT - padB) - barH;
          const barColor = d.color || color;
          return (
            <g key={i}>
              <rect x={x} y={y} width={w} height={barH} rx="3" fill={barColor} opacity="0.85" />
              <text x={x + w / 2} y={height - padB + 14} textAnchor="middle" fill="#64748b" fontSize="9" fontFamily="sans-serif">
                {d.label.length > 6 ? d.label.slice(0, 6) + '…' : d.label}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
