import { useEffect, useState } from 'react';
import { DollarSign, Users, ShoppingCart, TrendingUp, Activity, Target } from 'lucide-react';
import KPICard from '../components/KPICard';
import LineChart from '../components/charts/LineChart';
import DonutChart from '../components/charts/DonutChart';
import BarChart from '../components/charts/BarChart';
import { supabase } from '../lib/supabase';
import type { Customer, RevenueMetric } from '../lib/types';

const SEGMENT_COLORS: Record<string, string> = {
  vip: '#f59e0b',
  regular: '#3b82f6',
  new: '#10b981',
  at_risk: '#ef4444',
  dormant: '#64748b',
};

const CHANNEL_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#06b6d4'];

export default function Overview() {
  const [metrics, setMetrics] = useState<RevenueMetric[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [{ data: m }, { data: c }] = await Promise.all([
        supabase.from('revenue_metrics').select('*').order('date', { ascending: true }).limit(120),
        supabase.from('customers').select('*').limit(200),
      ]);
      if (m) setMetrics(m);
      if (c) setCustomers(c as Customer[]);
      setLoading(false);
    }
    load();
  }, []);

  const actual = metrics.filter(m => m.revenue > 0);
  const forecast = metrics.filter(m => (m.forecast_revenue ?? 0) > 0);

  const last30 = actual.slice(-30);
  const prev30 = actual.slice(-60, -30);
  const totalRev = last30.reduce((s, m) => s + m.revenue, 0);
  const prevRev = prev30.reduce((s, m) => s + m.revenue, 0);
  const revChange = prevRev > 0 ? ((totalRev - prevRev) / prevRev) * 100 : 0;

  const totalOrders = last30.reduce((s, m) => s + m.orders, 0);
  const prevOrders = prev30.reduce((s, m) => s + m.orders, 0);
  const ordChange = prevOrders > 0 ? ((totalOrders - prevOrders) / prevOrders) * 100 : 0;

  const avgOrderVal = totalOrders > 0 ? totalRev / totalOrders : 0;

  const segments = ['vip', 'regular', 'new', 'at_risk', 'dormant'];
  const segCounts = segments.map(s => ({
    label: s.charAt(0).toUpperCase() + s.slice(1).replace('_', ' '),
    value: customers.filter(c => c.segment === s).length,
    color: SEGMENT_COLORS[s],
  }));

  const channels = ['organic', 'paid_search', 'email', 'social'];
  const channelData = channels.map((ch, i) => ({
    label: ch === 'paid_search' ? 'Paid' : ch.charAt(0).toUpperCase() + ch.slice(1),
    value: customers.filter(c => c.acquisition_channel === ch).length,
    color: CHANNEL_COLORS[i],
  }));

  const chartData = [...actual.slice(-60), ...forecast.slice(0, 30)].map(m => ({
    label: new Date(m.date).toLocaleDateString('en', { month: 'short', day: 'numeric' }),
    value: m.revenue,
    forecast: m.forecast_revenue ?? 0,
  }));

  const weeklyData = Array.from({ length: 8 }, (_, i) => {
    const chunk = actual.slice(-(i + 1) * 7 - 7, -(i) * 7 || undefined).reverse();
    if (!chunk.length) return null;
    return {
      label: `W-${8 - i}`,
      value: chunk.reduce((s, m) => s + m.revenue, 0),
    };
  }).filter(Boolean).reverse() as { label: string; value: number }[];

  const atRiskCount = customers.filter(c => c.churn_risk > 0.6).length;
  const highLTVCount = customers.filter(c => c.ltv > 2000).length;

  return (
    <div className="space-y-6">
      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          label="Revenue (30d)" value={`$${(totalRev / 1000).toFixed(1)}K`}
          change={revChange} icon={<DollarSign size={18} />}
          accent="#3b82f6" loading={loading}
        />
        <KPICard
          label="Total Customers" value={customers.length.toLocaleString()}
          change={2.4} icon={<Users size={18} />}
          accent="#10b981" loading={loading}
          subtitle={`${customers.filter(c => c.segment === 'new').length} new this month`}
        />
        <KPICard
          label="Orders (30d)" value={totalOrders.toLocaleString()}
          change={ordChange} icon={<ShoppingCart size={18} />}
          accent="#f59e0b" loading={loading}
        />
        <KPICard
          label="Avg Order Value" value={`$${avgOrderVal.toFixed(0)}`}
          change={1.8} icon={<TrendingUp size={18} />}
          accent="#06b6d4" loading={loading}
        />
      </div>

      {/* Secondary KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          label="At-Risk Customers" value={atRiskCount.toString()}
          change={-8.2} icon={<Activity size={18} />}
          accent="#ef4444" loading={loading}
          subtitle="Churn risk > 60%"
        />
        <KPICard
          label="High-Value Customers" value={highLTVCount.toString()}
          change={5.1} icon={<Target size={18} />}
          accent="#f59e0b" loading={loading}
          subtitle="LTV > $2,000"
        />
        <KPICard
          label="Avg LTV" value={`$${customers.length ? (customers.reduce((s, c) => s + c.ltv, 0) / customers.length).toFixed(0) : 0}`}
          change={3.7} icon={<DollarSign size={18} />}
          accent="#a855f7" loading={loading}
        />
        <KPICard
          label="Avg Churn Risk" value={`${customers.length ? ((customers.reduce((s, c) => s + c.churn_risk, 0) / customers.length) * 100).toFixed(1) : 0}%`}
          change={-2.1} icon={<Activity size={18} />}
          accent="#06b6d4" loading={loading}
        />
      </div>

      {/* Revenue chart + Segment donut */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-slate-800 border border-slate-700 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-200">Revenue Trend & Forecast</h3>
              <p className="text-xs text-slate-500 mt-0.5">Last 60 days + 30-day AI forecast</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-0.5 bg-blue-500 rounded" />
                <span className="text-slate-400">Actual</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-0.5 bg-cyan-400 rounded border-dashed border border-cyan-400" />
                <span className="text-slate-400">Forecast</span>
              </div>
            </div>
          </div>
          {loading ? (
            <div className="h-48 bg-slate-700 rounded animate-pulse" />
          ) : (
            <LineChart data={chartData} height={200} color="#3b82f6" forecastColor="#06b6d4" showForecast
              formatValue={v => `$${(v / 1000).toFixed(0)}K`} />
          )}
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-1">Customer Segments</h3>
          <p className="text-xs text-slate-500 mb-4">ML-based segmentation</p>
          {loading ? (
            <div className="h-40 bg-slate-700 rounded animate-pulse" />
          ) : (
            <DonutChart data={segCounts} size={160} thickness={32} centerLabel="Customers" centerValue={customers.length.toString()} />
          )}
        </div>
      </div>

      {/* Weekly revenue bar + Acquisition channels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-1">Weekly Revenue</h3>
          <p className="text-xs text-slate-500 mb-4">Last 8 weeks</p>
          {loading ? (
            <div className="h-40 bg-slate-700 rounded animate-pulse" />
          ) : (
            <BarChart data={weeklyData} height={160} color="#3b82f6" formatValue={v => `$${(v / 1000).toFixed(0)}K`} />
          )}
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-1">Acquisition Channels</h3>
          <p className="text-xs text-slate-500 mb-4">Customer source distribution</p>
          {loading ? (
            <div className="h-40 bg-slate-700 rounded animate-pulse" />
          ) : (
            <DonutChart data={channelData} size={140} thickness={28} centerLabel="Channels" centerValue="4" />
          )}
        </div>
      </div>

      {/* AI Model Status */}
      <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
        <h3 className="text-sm font-semibold text-slate-200 mb-4">AI Model Status</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { name: 'Churn Predictor', algo: 'XGBoost Classifier', accuracy: '94.2%', status: 'active', color: '#10b981' },
            { name: 'LTV Estimator', algo: 'Random Forest Regressor', accuracy: '91.7%', status: 'active', color: '#3b82f6' },
            { name: 'Revenue Forecast', algo: 'Prophet + LSTM', accuracy: '88.4%', status: 'active', color: '#06b6d4' },
            { name: 'Segmentation', algo: 'K-Means Clustering', accuracy: '96.1%', status: 'active', color: '#f59e0b' },
          ].map((model, i) => (
            <div key={i} className="p-4 rounded-xl bg-slate-700/40 border border-slate-700">
              <div className="flex items-center gap-1.5 mb-2">
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: model.color }} />
                <span className="text-xs font-semibold text-slate-200">{model.name}</span>
              </div>
              <div className="text-xs text-slate-500 mb-2">{model.algo}</div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">Accuracy</span>
                <span className="text-sm font-bold" style={{ color: model.color }}>{model.accuracy}</span>
              </div>
              <div className="mt-2 h-1 bg-slate-700 rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: model.accuracy, backgroundColor: model.color, opacity: 0.7 }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
