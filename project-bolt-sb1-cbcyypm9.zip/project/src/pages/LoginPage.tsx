import { useState } from 'react';
import { BrainCircuit, Lock, Mail, Eye, EyeOff, BarChart3, TrendingUp, Users } from 'lucide-react';
import { useAuth } from '../lib/AuthContext';

const DEMO_EMAIL = 'demo@ecomm-analytics.io';
const DEMO_PASSWORD = 'DemoAccess2024!';

export default function LoginPage() {
  const { signIn } = useAuth();
  const [email, setEmail] = useState(DEMO_EMAIL);
  const [password, setPassword] = useState(DEMO_PASSWORD);
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const { error } = await signIn(email, password);
    if (error) setError(error.message);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Left panel */}
      <div className="hidden lg:flex flex-col justify-between w-1/2 bg-slate-900 border-r border-slate-800 p-12">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center">
            <BrainCircuit size={18} className="text-white" />
          </div>
          <div>
            <div className="text-sm font-bold text-slate-100">E-Commerce AI</div>
            <div className="text-xs text-slate-500">Analytics Platform</div>
          </div>
        </div>

        <div>
          <h2 className="text-3xl font-bold text-slate-100 leading-tight mb-4">
            AI-Powered Customer<br />Analytics & Prediction
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed mb-8">
            Leverage machine learning models to understand customer behavior,
            predict churn, forecast revenue, and optimize your product strategy.
          </p>

          <div className="space-y-4">
            {[
              { icon: <Users size={16} />, label: 'Customer Segmentation', desc: 'RFM-based ML clustering', color: '#3b82f6' },
              { icon: <TrendingUp size={16} />, label: 'Churn Prediction', desc: '94.2% model accuracy', color: '#10b981' },
              { icon: <BarChart3 size={16} />, label: 'Revenue Forecasting', desc: '30-day sales predictions', color: '#06b6d4' },
            ].map((f, i) => (
              <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
                <div className="p-2 rounded-lg mt-0.5" style={{ backgroundColor: `${f.color}20`, color: f.color }}>
                  {f.icon}
                </div>
                <div>
                  <div className="text-sm font-semibold text-slate-200">{f.label}</div>
                  <div className="text-xs text-slate-500">{f.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="text-xs text-slate-600">
          Powered by Python ML pipelines · scikit-learn · XGBoost · Prophet
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="lg:hidden mb-8 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <BrainCircuit size={16} className="text-white" />
            </div>
            <div className="text-sm font-bold text-slate-100">E-Commerce AI Analytics</div>
          </div>

          <h1 className="text-2xl font-bold text-slate-100 mb-1">Sign in to dashboard</h1>
          <p className="text-sm text-slate-400 mb-8">
            Demo credentials are pre-filled for easy access.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">Email address</label>
              <div className="relative">
                <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-4 py-2.5 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 transition-all"
                  placeholder="you@example.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">Password</label>
              <div className="relative">
                <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-10 py-2.5 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 transition-all"
                  required
                />
                <button type="button" onClick={() => setShowPass(p => !p)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors">
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold text-sm py-2.5 rounded-lg transition-colors"
            >
              {loading ? 'Signing in...' : 'Sign in to Dashboard'}
            </button>
          </form>

          <div className="mt-6 p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
            <div className="text-xs font-semibold text-slate-400 mb-1">Demo Account</div>
            <div className="text-xs text-slate-500 font-mono">{DEMO_EMAIL}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
