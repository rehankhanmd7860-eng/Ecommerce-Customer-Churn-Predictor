import { useEffect, useState } from 'react';
import { Star, Package, TrendingUp, DollarSign, BarChart3, Info } from 'lucide-react';
import BarChart from '../components/charts/BarChart';
import DonutChart from '../components/charts/DonutChart';
import KPICard from '../components/KPICard';
import { supabase } from '../lib/supabase';
import type { Product } from '../lib/types';

const CATEGORY_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#06b6d4', '#ef4444', '#a855f7'];

function StarsDisplay({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }, (_, i) => (
        <Star
          key={i}
          size={11}
          className={i < Math.floor(rating) ? 'text-amber-400 fill-amber-400' : i < rating ? 'text-amber-400 fill-amber-400/40' : 'text-slate-600'}
        />
      ))}
      <span className="text-xs text-slate-400 ml-1">{rating.toFixed(1)}</span>
    </div>
  );
}

export default function ProductInsights() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'revenue' | 'margin' | 'rating' | 'reviews_count'>('revenue');

  useEffect(() => {
    supabase.from('products').select('*').then(({ data }) => {
      if (data) setProducts(data as Product[]);
      setLoading(false);
    });
  }, []);

  const withRevenue = products.map(p => ({
    ...p,
    revenue: p.price * (p.reviews_count / 10 + p.stock / 20),
    margin: ((p.price - p.cost) / p.price) * 100,
    unitsSold: Math.round(p.reviews_count / 10 + p.stock / 20),
  }));

  const sorted = [...withRevenue].sort((a, b) => b[sortBy] - a[sortBy]);

  const totalRevenue = withRevenue.reduce((s, p) => s + p.revenue, 0);
  const avgMargin = withRevenue.length ? withRevenue.reduce((s, p) => s + p.margin, 0) / withRevenue.length : 0;
  const avgRating = withRevenue.length ? withRevenue.reduce((s, p) => s + p.rating, 0) / withRevenue.length : 0;
  const totalReviews = withRevenue.reduce((s, p) => s + p.reviews_count, 0);

  const categories = [...new Set(products.map(p => p.category))];
  const categoryData = categories.map((cat, i) => {
    const catProducts = withRevenue.filter(p => p.category === cat);
    return {
      label: cat,
      value: Math.round(catProducts.reduce((s, p) => s + p.revenue, 0)),
      color: CATEGORY_COLORS[i % CATEGORY_COLORS.length],
    };
  });

  const topByRevenue = withRevenue.slice().sort((a, b) => b.revenue - a.revenue).slice(0, 8).map(p => ({
    label: p.name.split(' ').slice(0, 2).join(' '),
    value: Math.round(p.revenue),
    color: '#3b82f6',
  }));

  const marginData = withRevenue.slice().sort((a, b) => b.margin - a.margin).slice(0, 8).map(p => ({
    label: p.name.split(' ').slice(0, 2).join(' '),
    value: Math.round(p.margin),
    color: '#10b981',
  }));

  // Mock recommendations
  const recommendations = [
    { product: 'Noise Cancelling Earbuds', reason: 'High rating + high review velocity', confidence: 94, action: 'Increase ad spend' },
    { product: 'Portable SSD 1TB', reason: 'Top margin product, low stock risk', confidence: 89, action: 'Restock + bundle offer' },
    { product: 'Smart Fitness Watch', reason: 'Trending in VIP segment', confidence: 86, action: 'VIP targeted campaign' },
    { product: 'Ergonomic Office Chair', reason: 'High AOV, good for upsell', confidence: 82, action: 'Cross-sell with desk mat' },
    { product: 'Mechanical Keyboard', reason: 'Strong review growth signal', confidence: 78, action: 'Featured placement' },
  ];

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          label="Total Products" value={products.length.toString()}
          icon={<Package size={18} />}
          accent="#3b82f6" loading={loading}
        />
        <KPICard
          label="Avg Gross Margin" value={`${avgMargin.toFixed(1)}%`}
          change={1.3} icon={<DollarSign size={18} />}
          accent="#10b981" loading={loading}
        />
        <KPICard
          label="Avg Product Rating" value={avgRating.toFixed(2)}
          icon={<Star size={18} />}
          accent="#f59e0b" loading={loading}
          subtitle={`${totalReviews.toLocaleString()} total reviews`}
        />
        <KPICard
          label="Total Est. Revenue" value={`$${(totalRevenue / 1000).toFixed(0)}K`}
          change={6.8} icon={<TrendingUp size={18} />}
          accent="#06b6d4" loading={loading}
        />
      </div>

      {/* Category distribution + Top by revenue */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-1">Revenue by Category</h3>
          <p className="text-xs text-slate-500 mb-4">Estimated revenue distribution</p>
          {!loading && <DonutChart data={categoryData} size={160} thickness={32} centerLabel="Categories" centerValue={categories.length.toString()} />}
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-1">Top Products by Revenue</h3>
          <p className="text-xs text-slate-500 mb-4">Estimated revenue contribution</p>
          {!loading && <BarChart data={topByRevenue} height={160} color="#3b82f6" formatValue={v => `$${(v / 1000).toFixed(0)}K`} />}
        </div>
      </div>

      {/* Margin chart */}
      <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
        <h3 className="text-sm font-semibold text-slate-200 mb-1">Gross Margin by Product</h3>
        <p className="text-xs text-slate-500 mb-4">Top 8 products by margin %</p>
        {!loading && <BarChart data={marginData} height={140} color="#10b981" formatValue={v => `${v}%`} />}
      </div>

      {/* AI Recommendations */}
      <div className="bg-slate-800 border border-slate-700 rounded-xl">
        <div className="px-5 py-4 border-b border-slate-700 flex items-center gap-2">
          <BarChart3 size={16} className="text-cyan-400" />
          <h3 className="text-sm font-semibold text-slate-200">AI Product Recommendations</h3>
          <span className="ml-auto text-xs text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-full">Collaborative Filtering</span>
        </div>
        <div className="divide-y divide-slate-700/50">
          {recommendations.map((rec, i) => (
            <div key={i} className="px-5 py-4 flex items-center gap-4 hover:bg-slate-700/20 transition-colors">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-bold text-sm flex-shrink-0">
                {i + 1}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-slate-200">{rec.product}</div>
                <div className="text-xs text-slate-500 mt-0.5">{rec.reason}</div>
              </div>
              <div className="text-center flex-shrink-0">
                <div className="text-sm font-bold text-emerald-400">{rec.confidence}%</div>
                <div className="text-xs text-slate-500">confidence</div>
              </div>
              <div className="flex-shrink-0 px-3 py-1.5 bg-blue-600/20 text-blue-400 text-xs font-medium rounded-lg border border-blue-600/30">
                {rec.action}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Product table */}
      <div className="bg-slate-800 border border-slate-700 rounded-xl">
        <div className="px-5 py-4 border-b border-slate-700 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-200">Product Catalog</h3>
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as typeof sortBy)}
            className="bg-slate-700 border border-slate-600 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
          >
            <option value="revenue">Sort by Revenue</option>
            <option value="margin">Sort by Margin</option>
            <option value="rating">Sort by Rating</option>
            <option value="reviews_count">Sort by Reviews</option>
          </select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-700">
                {['Product', 'Category', 'Price', 'Cost', 'Margin', 'Stock', 'Rating', 'Reviews', 'Est. Revenue'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-slate-500 font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i} className="border-b border-slate-700/50">
                    {Array.from({ length: 9 }).map((_, j) => (
                      <td key={j} className="px-4 py-3"><div className="h-3 bg-slate-700 rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              ) : sorted.map(p => (
                <tr key={p.id} className="border-b border-slate-700/50 hover:bg-slate-700/20 transition-colors">
                  <td className="px-4 py-3 font-semibold text-slate-200">{p.name}</td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-0.5 text-xs rounded-full bg-slate-700 text-slate-300">{p.category}</span>
                  </td>
                  <td className="px-4 py-3 text-slate-200 tabular-nums">${p.price.toFixed(2)}</td>
                  <td className="px-4 py-3 text-slate-400 tabular-nums">${p.cost.toFixed(2)}</td>
                  <td className="px-4 py-3">
                    <span className={`font-semibold tabular-nums ${p.margin > 65 ? 'text-emerald-400' : p.margin > 55 ? 'text-amber-400' : 'text-red-400'}`}>
                      {p.margin.toFixed(1)}%
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-300 tabular-nums">{p.stock.toLocaleString()}</td>
                  <td className="px-4 py-3"><StarsDisplay rating={p.rating} /></td>
                  <td className="px-4 py-3 text-slate-400 tabular-nums">{p.reviews_count.toLocaleString()}</td>
                  <td className="px-4 py-3 font-bold text-cyan-400 tabular-nums">${(p.revenue / 1000).toFixed(0)}K</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
        <div className="flex items-start gap-3">
          <Info size={15} className="text-slate-500 mt-0.5 flex-shrink-0" />
          <div>
            <div className="text-xs font-semibold text-slate-300 mb-1">About Product Recommendations</div>
            <div className="text-xs text-slate-500 leading-relaxed">
              Product recommendations are generated using collaborative filtering (matrix factorization) and content-based
              similarity scoring. The model analyzes purchase co-occurrence patterns, customer segment preferences, and
              product attribute vectors. Implemented in Python with scikit-learn and Surprise library, updated weekly.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
