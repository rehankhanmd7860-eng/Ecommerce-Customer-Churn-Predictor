import { useEffect, useState } from 'react';
import { Search, Filter, ArrowUpDown, Globe, Award } from 'lucide-react';
import DonutChart from '../components/charts/DonutChart';
import BarChart from '../components/charts/BarChart';
import { supabase } from '../lib/supabase';
import type { Customer } from '../lib/types';

const SEGMENT_COLORS: Record<string, string> = {
  vip: '#f59e0b',
  regular: '#3b82f6',
  new: '#10b981',
  at_risk: '#ef4444',
  dormant: '#64748b',
};

const SEGMENT_LABELS: Record<string, string> = {
  vip: 'VIP',
  regular: 'Regular',
  new: 'New',
  at_risk: 'At Risk',
  dormant: 'Dormant',
};

function riskBadge(risk: number) {
  if (risk > 0.65) return <span className="px-2 py-0.5 text-xs rounded-full bg-red-500/15 text-red-400 font-medium">{(risk * 100).toFixed(0)}%</span>;
  if (risk > 0.35) return <span className="px-2 py-0.5 text-xs rounded-full bg-amber-500/15 text-amber-400 font-medium">{(risk * 100).toFixed(0)}%</span>;
  return <span className="px-2 py-0.5 text-xs rounded-full bg-emerald-500/15 text-emerald-400 font-medium">{(risk * 100).toFixed(0)}%</span>;
}

export default function CustomerAnalytics() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterSegment, setFilterSegment] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'ltv' | 'churn_risk' | 'total_spent'>('ltv');
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 12;

  useEffect(() => {
    supabase.from('customers').select('*').limit(200).then(({ data }) => {
      if (data) setCustomers(data as Customer[]);
      setLoading(false);
    });
  }, []);

  const filtered = customers
    .filter(c =>
      (filterSegment === 'all' || c.segment === filterSegment) &&
      (search === '' || c.name.toLowerCase().includes(search.toLowerCase()) || c.email.toLowerCase().includes(search.toLowerCase()))
    )
    .sort((a, b) => b[sortBy] - a[sortBy]);

  const paged = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const segments = ['vip', 'regular', 'new', 'at_risk', 'dormant'];
  const segData = segments.map(s => ({
    label: SEGMENT_LABELS[s],
    value: customers.filter(c => c.segment === s).length,
    color: SEGMENT_COLORS[s],
  }));

  const countries = ['US', 'UK', 'CA', 'AU', 'DE'];
  const countryData = countries.map(co => ({
    label: co,
    value: customers.filter(c => c.country === co).length,
    color: '#3b82f6',
  }));

  const avgLTVBySegment = segments.map(s => {
    const seg = customers.filter(c => c.segment === s);
    return {
      label: SEGMENT_LABELS[s],
      value: seg.length ? Math.round(seg.reduce((s, c) => s + c.ltv, 0) / seg.length) : 0,
      color: SEGMENT_COLORS[s],
    };
  });

  return (
    <div className="space-y-6">
      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {segments.map(s => {
          const segCustomers = customers.filter(c => c.segment === s);
          const avgLtv = segCustomers.length ? segCustomers.reduce((a, c) => a + c.ltv, 0) / segCustomers.length : 0;
          return (
            <div key={s} className="bg-slate-800 border border-slate-700 rounded-xl p-4 hover:border-slate-600 transition-colors">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: SEGMENT_COLORS[s] }} />
                <span className="text-xs font-semibold text-slate-300">{SEGMENT_LABELS[s]}</span>
              </div>
              <div className="text-2xl font-bold text-slate-100">{segCustomers.length}</div>
              <div className="text-xs text-slate-500 mt-0.5">
                {customers.length ? ((segCustomers.length / customers.length) * 100).toFixed(0) : 0}% of total
              </div>
              <div className="text-xs text-slate-400 mt-1">Avg LTV: <span className="font-semibold">${avgLtv.toFixed(0)}</span></div>
            </div>
          );
        })}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-1">Segment Distribution</h3>
          <p className="text-xs text-slate-500 mb-4">ML-based clustering</p>
          {!loading && <DonutChart data={segData} size={150} thickness={30} centerLabel="Customers" centerValue={customers.length.toString()} />}
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-1">Avg LTV by Segment</h3>
          <p className="text-xs text-slate-500 mb-4">Customer lifetime value</p>
          {!loading && <BarChart data={avgLTVBySegment} height={160} formatValue={v => `$${v}`} />}
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-1">
            <Globe size={14} className="text-slate-400" />
            <h3 className="text-sm font-semibold text-slate-200">Geographic Distribution</h3>
          </div>
          <p className="text-xs text-slate-500 mb-4">Top customer countries</p>
          {!loading && <BarChart data={countryData} height={160} color="#06b6d4" />}
        </div>
      </div>

      {/* Customer table */}
      <div className="bg-slate-800 border border-slate-700 rounded-xl">
        <div className="p-5 border-b border-slate-700">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <h3 className="text-sm font-semibold text-slate-200 flex-1">Customer Directory</h3>
            <div className="flex items-center gap-2 flex-wrap">
              {/* Search */}
              <div className="relative">
                <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search customers..."
                  value={search}
                  onChange={e => { setSearch(e.target.value); setPage(0); }}
                  className="bg-slate-700 border border-slate-600 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 w-44"
                />
              </div>
              {/* Segment filter */}
              <div className="relative">
                <Filter size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <select
                  value={filterSegment}
                  onChange={e => { setFilterSegment(e.target.value); setPage(0); }}
                  className="bg-slate-700 border border-slate-600 rounded-lg pl-7 pr-6 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 appearance-none"
                >
                  <option value="all">All Segments</option>
                  {segments.map(s => <option key={s} value={s}>{SEGMENT_LABELS[s]}</option>)}
                </select>
              </div>
              {/* Sort */}
              <div className="relative">
                <ArrowUpDown size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <select
                  value={sortBy}
                  onChange={e => setSortBy(e.target.value as typeof sortBy)}
                  className="bg-slate-700 border border-slate-600 rounded-lg pl-7 pr-6 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 appearance-none"
                >
                  <option value="ltv">Sort by LTV</option>
                  <option value="churn_risk">Sort by Churn Risk</option>
                  <option value="total_spent">Sort by Spent</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-700">
                {['Customer', 'Segment', 'Total Spent', 'Orders', 'Avg Order', 'LTV', 'Predicted LTV', 'Churn Risk', 'Days Inactive'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-slate-500 font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i} className="border-b border-slate-700/50">
                    {Array.from({ length: 9 }).map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="h-3 bg-slate-700 rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : paged.map(c => (
                <tr key={c.id} className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors">
                  <td className="px-4 py-3">
                    <div className="font-semibold text-slate-200">{c.name}</div>
                    <div className="text-slate-500">{c.email}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: `${SEGMENT_COLORS[c.segment]}20`, color: SEGMENT_COLORS[c.segment] }}>
                      {SEGMENT_LABELS[c.segment]}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-semibold text-slate-200 tabular-nums">${c.total_spent.toLocaleString()}</td>
                  <td className="px-4 py-3 text-slate-300 tabular-nums">{c.total_orders}</td>
                  <td className="px-4 py-3 text-slate-300 tabular-nums">${c.avg_order_value.toFixed(0)}</td>
                  <td className="px-4 py-3 font-semibold text-amber-400 tabular-nums">${c.ltv.toLocaleString()}</td>
                  <td className="px-4 py-3 font-semibold text-cyan-400 tabular-nums">${c.predicted_ltv.toLocaleString()}</td>
                  <td className="px-4 py-3">{riskBadge(c.churn_risk)}</td>
                  <td className="px-4 py-3 text-slate-400 tabular-nums">{c.days_since_last_order}d</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-5 py-3 border-t border-slate-700 flex items-center justify-between">
          <span className="text-xs text-slate-500">{filtered.length} customers</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
              className="px-3 py-1 text-xs rounded-lg bg-slate-700 text-slate-300 disabled:opacity-40 hover:bg-slate-600 transition-colors">
              Prev
            </button>
            <span className="text-xs text-slate-400">{page + 1} / {Math.max(1, totalPages)}</span>
            <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1}
              className="px-3 py-1 text-xs rounded-lg bg-slate-700 text-slate-300 disabled:opacity-40 hover:bg-slate-600 transition-colors">
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
